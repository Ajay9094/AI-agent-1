import argparse
import json
import os
import re
import sqlite3
import time
import uuid
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
DB_FILE = ROOT / "campusmate.db"
TRACE_FILE = ROOT / "agent_traces.jsonl"
HANDBOOK_FILE = ROOT / "student_handbook.txt"
API_URL = "https://api.groq.com/openai/v1/chat/completions"
MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
MAX_TOOL_ROUNDS = 5


# ---------------------------------------------------------------------
# 1. CONFIGURATION AND SAMPLE POLICY DOCUMENT
# ---------------------------------------------------------------------

def load_env_file():
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def timestamp():
    return datetime.now().isoformat(timespec="seconds")


def create_handbook_if_missing():
    if HANDBOOK_FILE.exists():
        return
    handbook = """STUDENT HANDBOOK - SAMPLE POLICY DOCUMENT

FEES AND PAYMENT
Students can pay academic fees through the institution's student ERP portal.
Accepted payment methods are UPI, debit card and net banking. A late payment
charge may apply after the published due date. If a payment fails, students
should retain the transaction reference and contact the accounts office.
The handbook does not guarantee an automatic extension to the payment deadline.

ATTENDANCE
Students should maintain at least 75 percent attendance in each course to be
eligible for the end-term examination. Any attendance relaxation must be
approved by the academic office under the institution's applicable rules.

SCHOLARSHIPS
Scholarship applications are reviewed by the scholarship committee. Approval
depends on the scheme criteria, supporting documents and committee decision.
Students can ask the student support office for an application-status update.
This handbook does not define an individual student's award status.

COURSE CHANGE
A course-change request must be submitted to the academic office during the
announced add/drop period. Approval depends on seat availability and academic
approval. Students should not assume a course change is complete until written
confirmation is received.

STUDENT SUPPORT
Students may raise a support request for academic, fee, portal or campus issues.
A request should include a short description and a preferred contact method.
Urgent or safety-related matters should be reported directly to the relevant
college office rather than relying only on the chatbot.
"""
    HANDBOOK_FILE.write_text(handbook, encoding="utf-8")


def split_policy_into_chunks():
    """Create small retrieval units instead of sending the entire handbook."""
    text = HANDBOOK_FILE.read_text(encoding="utf-8")
    sections = re.split(r"\n(?=[A-Z][A-Z &-]+\n)", text)
    chunks = []
    for number, section in enumerate(sections, start=1):
        cleaned = section.strip()
        if cleaned:
            chunks.append({"chunk_id": f"POL-{number:02d}", "text": cleaned})
    return chunks


POLICY_CHUNKS = []


def retrieve_policy(question, limit=2):
    """Simple keyword retrieval; returns only the most relevant policy chunks."""
    words = set(re.findall(r"[a-z]{3,}", question.lower()))
    scored = []
    for chunk in POLICY_CHUNKS:
        content_words = set(re.findall(r"[a-z]{3,}", chunk["text"].lower()))
        score = len(words & content_words)
        if score:
            scored.append((score, chunk))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [chunk for _, chunk in scored[:limit]]


# ---------------------------------------------------------------------
# 2. DATABASE, STUDENT RECORDS, MEMORY AND SUPPORT REQUESTS
# ---------------------------------------------------------------------

def connect_db():
    connection = sqlite3.connect(DB_FILE)
    connection.row_factory = sqlite3.Row
    return connection


def setup_database():
    with connect_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY,
            student_name TEXT NOT NULL,
            programme TEXT NOT NULL,
            fee_total INTEGER NOT NULL,
            fee_paid INTEGER NOT NULL,
            fee_due_date TEXT,
            scholarship TEXT,
            scholarship_status TEXT
        );

        CREATE TABLE IF NOT EXISTS conversation_memory (
            memory_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            memory_text TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS support_tickets (
            ticket_id TEXT PRIMARY KEY,
            student_id TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        count = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        if count == 0:
            demo_students = [
                ("STU1001", "Aarav Shah", "PGDM AI & DS", 150000, 90000,
                 "2026-11-15", "Merit Scholarship", "Approved"),
                ("STU1002", "Diya Patel", "PGDM Big Data Analytics", 150000,
                 150000, "Paid", "Need-based Grant", "Under Review"),
                ("STU1003", "Kabir Mehta", "PGDM AI & DS", 150000, 50000,
                 "2026-11-15", "Not Applied", "Not Applied"),
            ]
            db.executemany(
                "INSERT INTO students VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                demo_students
            )


def get_student(student_id):
    with connect_db() as db:
        row = db.execute(
            "SELECT * FROM students WHERE student_id = ?",
            (student_id.upper(),)
        ).fetchone()
    return dict(row) if row else None


def read_memory(student_id, limit=6):
    with connect_db() as db:
        rows = db.execute(
            """SELECT memory_text FROM conversation_memory
               WHERE student_id = ? ORDER BY memory_id DESC LIMIT ?""",
            (student_id, limit)
        ).fetchall()
    return [row["memory_text"] for row in reversed(rows)]


def save_memory(student_id, memory_text):
    """Store only useful, non-sensitive information."""
    if re.search(r"(?i)\b(otp|password|passcode|cvv|one.time.code)\b", memory_text):
        return False
    with connect_db() as db:
        db.execute(
            """INSERT INTO conversation_memory(student_id, memory_text, created_at)
               VALUES (?, ?, ?)""",
            (student_id, memory_text[:400], timestamp())
        )
    return True


# ---------------------------------------------------------------------
# 3. AGENT TOOLS
# ---------------------------------------------------------------------

def tool_fee_status(student_id, arguments):
    student = get_student(student_id)
    if not student:
        return {"status": "error", "message": "Student record was not found."}
    due = student["fee_total"] - student["fee_paid"]
    return {
        "status": "success",
        "student_id": student_id,
        "total_fee": student["fee_total"],
        "paid_amount": student["fee_paid"],
        "pending_amount": due,
        "due_date": student["fee_due_date"]
    }


def tool_scholarship_status(student_id, arguments):
    student = get_student(student_id)
    if not student:
        return {"status": "error", "message": "Student record was not found."}
    return {
        "status": "success",
        "scholarship": student["scholarship"],
        "application_status": student["scholarship_status"]
    }


def tool_create_ticket(student_id, arguments):
    category = str(arguments.get("category", "General"))[:40]
    description = str(arguments.get("description", "")).strip()[:500]
    if len(description) < 5:
        return {"status": "error", "message": "Please provide a little more detail."}
    ticket_id = "REQ-" + uuid.uuid4().hex[:7].upper()
    with connect_db() as db:
        db.execute(
            """INSERT INTO support_tickets
               (ticket_id, student_id, category, description, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (ticket_id, student_id, category, description, "Open", timestamp())
        )
    return {
        "status": "success",
        "ticket_id": ticket_id,
        "ticket_status": "Open",
        "message": "Your support request has been created."
    }


def tool_policy_search(student_id, arguments):
    question = str(arguments.get("question", ""))
    matches = retrieve_policy(question)
    if not matches:
        return {
            "status": "not_found",
            "evidence": [],
            "message": "The handbook does not contain enough information to answer this."
        }
    return {
        "status": "success",
        "evidence": matches,
        "message": "Relevant handbook sections retrieved."
    }


def tool_save_preference(student_id, arguments):
    note = str(arguments.get("preference", "")).strip()
    if not note:
        return {"status": "error", "message": "No preference was provided."}
    saved = save_memory(student_id, note)
    return {
        "status": "success" if saved else "blocked",
        "message": "Preference saved for future chats." if saved
        else "Sensitive information is not stored in long-term memory."
    }


TOOL_FUNCTIONS = {
    "check_fee_status": tool_fee_status,
    "check_scholarship_status": tool_scholarship_status,
    "create_support_ticket": tool_create_ticket,
    "search_student_policy": tool_policy_search,
    "save_student_preference": tool_save_preference,
}

TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "check_fee_status",
            "description": "Retrieve the signed-in student's fee total, paid amount and pending amount.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "check_scholarship_status",
            "description": "Retrieve the signed-in student's scholarship application status.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_support_ticket",
            "description": "Create a support request for the signed-in student.",
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {"type": "string"},
                    "description": {"type": "string"}
                },
                "required": ["category", "description"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_student_policy",
            "description": "Retrieve relevant information from the student handbook for policy questions.",
            "parameters": {
                "type": "object",
                "properties": {"question": {"type": "string"}},
                "required": ["question"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "save_student_preference",
            "description": "Save a useful non-sensitive student preference for a future session.",
            "parameters": {
                "type": "object",
                "properties": {"preference": {"type": "string"}},
                "required": ["preference"]
            }
        }
    }
]


# ---------------------------------------------------------------------
# 4. GROQ CLIENT AND OFFLINE MOCK
# ---------------------------------------------------------------------

class GroqClient:
    def __init__(self, api_key, model_name):
        self.api_key = api_key
        self.model_name = model_name

    def chat(self, messages):
        request_body = {
            "model": self.model_name,
            "messages": messages,
            "tools": TOOL_DEFINITIONS,
            "tool_choice": "auto",
            "temperature": 0.2
        }
        request = urllib.request.Request(
            API_URL,
            data=json.dumps(request_body).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer " + self.api_key
            }
        )
        with urllib.request.urlopen(request, timeout=90) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage", {})
        return {
            "message": payload["choices"][0]["message"],
            "input_tokens": usage.get("prompt_tokens", 0),
            "output_tokens": usage.get("completion_tokens", 0)
        }


class OfflineClient:
    """A predictable mock model for testing without a Groq API key."""

    def chat(self, messages):
        latest_user_index = max(i for i, item in enumerate(messages) if item["role"] == "user")
        latest = messages[latest_user_index]["content"]
        # Once a tool has replied to the current question, produce a final answer
        # instead of requesting the same tool repeatedly.
        tool_replies = [m for m in messages[latest_user_index + 1:] if m["role"] == "tool"]
        if tool_replies:
            details = []
            for item in tool_replies:
                try:
                    payload = json.loads(item.get("content", "{}"))
                except json.JSONDecodeError:
                    payload = {"message": item.get("content", "")}
                details.append(payload)
            msg = {"role": "assistant", "content": "Here is the information I found: " + json.dumps(details, ensure_ascii=False)}
            return {"message": msg,
                    "input_tokens": max(1, len(json.dumps(messages)) // 4),
                    "output_tokens": max(1, len(json.dumps(msg)) // 4)}

        text = latest.lower()
        call = None

        if any(word in text for word in ("attendance", "hostel", "course change",
                                          "late fee", "payment portal", "handbook", "policy", "extension")):
            call = ("search_student_policy", {"question": latest})
        elif "fee" in text or "payment status" in text:
            call = ("check_fee_status", {})
        elif "scholarship" in text:
            call = ("check_scholarship_status", {})
        elif "remember" in text or "save my preference" in text:
            preference = re.sub(r"(?i)^.*?(remember|save my preference)\s*", "", latest)
            call = ("save_student_preference", {"preference": preference or latest})
        elif "ticket" in text or "support request" in text or "portal failed" in text:
            call = ("create_support_ticket", {
                "category": "Portal / General Support",
                "description": latest
            })

        if call:
            name, args = call
            msg = {
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": "offline-" + uuid.uuid4().hex[:8],
                    "type": "function",
                    "function": {"name": name, "arguments": json.dumps(args)}
                }]
            }
        else:
            msg = {
                "role": "assistant",
                "content": "I can help with fees, scholarships, handbook policies and support requests. Please ask a specific question."
            }

        return {
            "message": msg,
            "input_tokens": max(1, len(json.dumps(messages)) // 4),
            "output_tokens": max(1, len(json.dumps(msg)) // 4)
        }


def make_llm(offline=False):
    load_env_file()
    key = os.getenv("GROQ_API_KEY")
    if offline or not key:
        return OfflineClient(), "Offline mock"
    return GroqClient(key, MODEL), MODEL


# ---------------------------------------------------------------------
# 5. AGENT LOOP, CONTEXT SELECTION AND TRACE LOGGING
# ---------------------------------------------------------------------

class StudentAgent:
    def __init__(self, student_id, llm):
        self.student_id = student_id.upper()
        self.llm = llm
        self.history = []
        self.last_trace = None
        student = get_student(self.student_id)
        if not student:
            raise ValueError("Unknown student ID. Try STU1001, STU1002 or STU1003.")
        self.student_name = student["student_name"]
        self.programme = student["programme"]

    def system_message(self):
        memories = read_memory(self.student_id)
        memory_text = "\n".join("- " + item for item in memories) or "- No saved preferences."
        return {
            "role": "system",
            "content": (
                "You are CampusMate, an AI student support assistant. "
                f"The signed-in student is {self.student_name}, ID {self.student_id}, "
                f"programme {self.programme}. Use tools whenever personal records, "
                "policy evidence, memory storage or support-ticket creation is needed. "
                "Never invent student record values or policy rules. Only use the tool "
                "result and retrieved handbook evidence. If the handbook has no answer, "
                "say that the available policy document does not specify it and direct "
                "the student to the relevant college office. Do not claim a ticket was "
                "created unless the tool confirms success. Do not store passwords, OTPs, "
                "payment card details or other sensitive information. Be concise and helpful.\n"
                "Relevant long-term memory:\n" + memory_text
            )
        }

    def respond(self, user_text):
        started = time.perf_counter()
        trace = {
            "trace_id": uuid.uuid4().hex[:10],
            "time": timestamp(),
            "student_id": self.student_id,
            "question": user_text,
            "tool_calls": [],
            "retrieved_chunks": [],
            "input_tokens": 0,
            "output_tokens": 0
        }

        self.history.append({"role": "user", "content": user_text})
        answer = None
        messages = [self.system_message()] + self.history[-12:]

        try:
            for _ in range(MAX_TOOL_ROUNDS):
                call_start = time.perf_counter()
                result = self.llm.chat(messages)
                trace["input_tokens"] += result["input_tokens"]
                trace["output_tokens"] += result["output_tokens"]
                message = result["message"]
                messages.append(message)

                if not message.get("tool_calls"):
                    answer = message.get("content") or "I could not prepare a response."
                    break

                for tool_call in message["tool_calls"]:
                    function_data = tool_call["function"]
                    tool_name = function_data["name"]
                    arguments = json.loads(function_data.get("arguments") or "{}")

                    if tool_name not in TOOL_FUNCTIONS:
                        tool_result = {"status": "error", "message": "Tool is not available."}
                    else:
                        tool_result = TOOL_FUNCTIONS[tool_name](self.student_id, arguments)

                    if tool_name == "search_student_policy":
                        trace["retrieved_chunks"].extend(
                            item["chunk_id"] for item in tool_result.get("evidence", [])
                        )

                    trace["tool_calls"].append({
                        "tool": tool_name,
                        "arguments": arguments,
                        "status": tool_result.get("status"),
                        "latency_seconds": round(time.perf_counter() - call_start, 3)
                    })
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call["id"],
                        "content": json.dumps(tool_result)
                    })

            if answer is None:
                answer = "I could not complete the request within the tool-call limit."

        except (urllib.error.URLError, TimeoutError, ValueError, KeyError) as error:
            answer = "I encountered a processing issue. Please try again. (" + str(error)[:160] + ")"
            trace["error"] = str(error)

        self.history.append({"role": "assistant", "content": answer})
        trace["answer"] = answer
        trace["latency_seconds"] = round(time.perf_counter() - started, 3)
        self.last_trace = trace

        with TRACE_FILE.open("a", encoding="utf-8") as file:
            file.write(json.dumps(trace, ensure_ascii=False) + "\n")

        # Save only a short, non-sensitive interaction summary.
        safe_question = re.sub(
            r"(?i)\b(password|otp|passcode)\b\s*(is|:|=)?\s*\S+",
            "[sensitive information removed]", user_text
        )
        if not re.search(r"(?i)\b(otp|password|passcode|cvv)\b", safe_question):
            save_memory(self.student_id, "Recent topic: " + safe_question[:250])

        return answer


# ---------------------------------------------------------------------
# 6. EVALUATION: ACCURACY, TOOLS, LATENCY, TOKENS AND EVIDENCE
# ---------------------------------------------------------------------

def run_evaluation(llm):
    tests = [
        ("Fee status", "What is my current fee status?", "check_fee_status"),
        ("Scholarship", "Can you check my scholarship status?", "check_scholarship_status"),
        ("Attendance policy", "What attendance is required for exams?", "search_student_policy"),
        ("Support request", "Create a support request because my portal failed.", "create_support_ticket"),
        ("Unknown policy", "Does the handbook guarantee a fee extension after portal failure?",
         "search_student_policy")
    ]

    results = []
    for label, question, expected_tool in tests:
        agent = StudentAgent("STU1001", llm)
        reply = agent.respond(question)
        trace = agent.last_trace
        used = [item["tool"] for item in trace["tool_calls"]]
        passed = expected_tool in used and bool(reply.strip())
        results.append({
            "scenario": label,
            "passed": passed,
            "tools": ", ".join(used) or "None",
            "latency": trace["latency_seconds"],
            "input_tokens": trace["input_tokens"],
            "output_tokens": trace["output_tokens"],
            "evidence": ", ".join(trace["retrieved_chunks"]) or "No policy chunk"
        })

    print("\nCAMPUSMATE - EVALUATION RESULTS")
    print("-" * 105)
    print(f"{'Scenario':22} {'Result':8} {'Tools':28} {'Latency':10} {'Tokens In/Out':16} Evidence")
    print("-" * 105)
    for row in results:
        print(
            f"{row['scenario'][:21]:22} "
            f"{'PASS' if row['passed'] else 'CHECK':8} "
            f"{row['tools'][:27]:28} "
            f"{row['latency']:<10.3f} "
            f"{row['input_tokens']}/{row['output_tokens']:<11} "
            f"{row['evidence']}"
        )

    total = len(results)
    successful = sum(row["passed"] for row in results)
    print("-" * 105)
    print(f"Task/tool-selection success: {successful}/{total} ({successful / total * 100:.1f}%)")
    print("Note: Offline mode uses estimated token counts; live mode uses API-reported usage.")
    return results


# ---------------------------------------------------------------------
# 7. SIMPLE CHAT INTERFACE (STANDARD LIBRARY HTTP SERVER)
# ---------------------------------------------------------------------
HTML_PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CampusMate Student Support</title>
<style>
:root{
  --bg:#eef2f9;--card:#ffffff;--text:#1d2433;--muted:#6b7488;--line:#e2e7f0;
  --primary:#2f5fb3;--primary-dark:#234a8f;--user:#e6eeff;--bot:#f2f4f8;--ok:#1f9d6b;--err:#c0392b;--warn:#c27a0a;
}
body.dark{
  --bg:#0f1420;--card:#171e2e;--text:#e8ecf5;--muted:#93a0b8;--line:#2a3550;
  --primary:#5b8def;--primary-dark:#4274d6;--user:#223357;--bot:#1f2840;
}
*{box-sizing:border-box}
body{font-family:"Segoe UI",Arial,sans-serif;background:var(--bg);color:var(--text);margin:0;transition:background .2s}
header{background:linear-gradient(135deg,#1e3a6e,#3563b0);color:#fff;padding:16px 24px;display:flex;align-items:center;justify-content:space-between}
header .brand{display:flex;align-items:center;gap:12px}
.logo{width:40px;height:40px;border-radius:10px;background:#ffffff22;display:grid;place-items:center;font-size:22px}
header h1{font-size:18px;margin:0}
header small{opacity:.8}
.toggle{background:#ffffff22;border:1px solid #ffffff44;color:#fff;border-radius:20px;padding:6px 14px;cursor:pointer;font-size:13px}
main{max-width:960px;margin:22px auto;padding:0 14px;display:grid;grid-template-columns:260px 1fr;gap:18px}
@media(max-width:760px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;box-shadow:0 4px 18px #0000000d}
h2{font-size:16px;margin:0 0 10px}
.small{color:var(--muted);font-size:13px}
input,button{font:inherit;border-radius:9px}
input{width:100%;padding:11px;border:1px solid var(--line);background:var(--card);color:var(--text);outline:none}
input:focus{border-color:var(--primary);box-shadow:0 0 0 3px #2f5fb322}
button{border:0;cursor:pointer;padding:11px 16px;background:var(--primary);color:#fff;transition:.15s}
button:hover{background:var(--primary-dark)}
button:disabled{opacity:.5;cursor:not-allowed}
button.ghost{background:transparent;color:var(--primary);border:1px solid var(--line)}
.chip{display:block;width:100%;text-align:left;margin-top:8px;padding:9px 11px;font-size:13px;background:var(--bot);color:var(--text);border:1px solid var(--line)}
.chip:hover{background:var(--user);color:var(--text)}
.idbtn{display:inline-block;margin:6px 6px 0 0;padding:6px 12px;font-size:13px}
#status{margin:10px 0 0;font-size:13px}
#status.ok{color:var(--ok)}#status.err{color:var(--err)}
.chatwrap{display:flex;flex-direction:column;min-height:560px}
.chathead{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.badge{font-size:12px;background:var(--user);color:var(--primary);padding:4px 10px;border-radius:20px}
#chat{flex:1;height:410px;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:14px;background:var(--card)}
.empty{color:var(--muted);text-align:center;margin-top:120px;font-size:14px}
.msg{max-width:82%;padding:10px 13px;margin:10px 0;border-radius:12px;white-space:pre-wrap;line-height:1.45;font-size:14.5px;animation:pop .18s ease}
.msg.rich{white-space:normal;min-width:260px}
.msg time{display:block;font-size:11px;color:var(--muted);margin-top:5px}
.user{background:var(--user);margin-left:auto;border-bottom-right-radius:3px}
.bot{background:var(--bot);margin-right:auto;border-bottom-left-radius:3px}
@keyframes pop{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.dots span{display:inline-block;width:7px;height:7px;margin:0 2px;border-radius:50%;background:var(--muted);animation:b 1s infinite}
.dots span:nth-child(2){animation-delay:.15s}.dots span:nth-child(3){animation-delay:.3s}
@keyframes b{0%,80%,100%{opacity:.3;transform:scale(.8)}40%{opacity:1;transform:scale(1.15)}}
.row{display:flex;gap:8px;margin-top:12px}
.hidden{display:none!important}
footer{text-align:center;color:var(--muted);font-size:12px;padding:6px 0 24px}

/* Formatted result cards */
.rc{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin:2px 0 8px}
.rc:last-child{margin-bottom:2px}
.rc-title{font-weight:600;font-size:14px;margin-bottom:8px;display:flex;align-items:center;gap:6px}
.rc-row{display:flex;justify-content:space-between;gap:14px;padding:5px 0;border-bottom:1px dashed var(--line);font-size:14px}
.rc-row:last-of-type{border-bottom:0}
.rc-row span:first-child{color:var(--muted)}
.rc-row b{font-weight:600;text-align:right}
.pending{color:var(--err)}.clear{color:var(--ok)}
.bar{height:9px;background:var(--line);border-radius:6px;overflow:hidden;margin:10px 0 4px}
.bar>div{height:100%;background:linear-gradient(90deg,#2f5fb3,#1f9d6b);border-radius:6px;transition:width .6s ease}
.pill{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600}
.pill.ok{background:#1f9d6b22;color:var(--ok)}
.pill.warn{background:#c27a0a22;color:var(--warn)}
.pill.err{background:#c0392b22;color:var(--err)}
.pill.info{background:var(--user);color:var(--primary)}
.ev{border-left:3px solid var(--primary);padding:6px 10px;margin:6px 0;background:var(--bot);border-radius:0 8px 8px 0;font-size:13.5px;white-space:pre-wrap}
.ev .tag{font-size:11px;color:var(--primary);font-weight:700;display:block;margin-bottom:3px}
.note{font-size:13px;color:var(--muted);margin-top:6px}
</style>
</head>
<body>
<header>
  <div class="brand">
    <div class="logo">🎓</div>
    <div><h1>CampusMate</h1><small>Intelligent Student Support Agent</small></div>
  </div>
  <button class="toggle" onclick="toggleTheme()">🌓 Theme</button>
</header>

<main>
  <aside class="card">
    <h2>Student Sign-in</h2>
    <p class="small">Demo IDs (tap to fill):</p>
    <div>
      <button class="ghost idbtn" onclick="fillId('STU1001')">STU1001</button>
      <button class="ghost idbtn" onclick="fillId('STU1002')">STU1002</button>
      <button class="ghost idbtn" onclick="fillId('STU1003')">STU1003</button>
    </div>
    <div class="row">
      <input id="student" placeholder="Enter student ID" value="STU1001" onkeydown="if(event.key==='Enter')login()">
    </div>
    <div class="row"><button style="width:100%" onclick="login()">Start Chat</button></div>
    <p id="status" class="small">Enter a demo student ID to begin.</p>

    <div id="suggest" class="hidden">
      <h2 style="margin-top:18px">Try asking</h2>
      <button class="chip" onclick="ask(this.textContent)">What is my current fee status?</button>
      <button class="chip" onclick="ask(this.textContent)">Can you check my scholarship status?</button>
      <button class="chip" onclick="ask(this.textContent)">What attendance is required for exams?</button>
      <button class="chip" onclick="ask(this.textContent)">Create a support ticket because my portal failed.</button>
      <button class="chip" onclick="ask(this.textContent)">Does the handbook guarantee a fee extension?</button>
      <button class="chip" onclick="ask(this.textContent)">Remember that I prefer short answers.</button>
    </div>
  </aside>

  <section class="card chatwrap">
    <div class="chathead">
      <h2 style="margin:0">Student Support Chat</h2>
      <div>
        <span id="who" class="badge hidden"></span>
        <button class="ghost hidden" id="clearBtn" style="padding:5px 10px;font-size:12px" onclick="clearChat()">Clear</button>
      </div>
    </div>
    <div id="chat">
      <div class="empty" id="empty">👋 Sign in with a demo student ID to start chatting.</div>
    </div>
    <div id="composer" class="row hidden">
      <input id="question" maxlength="1000" placeholder="Ask about fees, scholarships or policies..." onkeydown="if(event.key==='Enter')send()">
      <button id="sendBtn" onclick="send()">Send</button>
    </div>
    <p class="small" style="margin:10px 0 0">Urgent or safety-related matters should be reported directly to the college office.</p>
  </section>
</main>
<footer>Academic demonstration using sample student records only.</footer>

<script>
let studentId="", busy=false;
const chat=document.getElementById("chat");

function toggleTheme(){
  document.body.classList.toggle("dark");
  try{localStorage.setItem("cm_theme",document.body.classList.contains("dark")?"dark":"light");}catch(e){}
}
try{if(localStorage.getItem("cm_theme")==="dark")document.body.classList.add("dark");}catch(e){}

function fillId(id){document.getElementById("student").value=id;}
function now(){return new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});}

/* ---------- Helpers to build formatted result cards (safe DOM, no innerHTML) ---------- */
function el(tag,cls,text){
  const e=document.createElement(tag);
  if(cls)e.className=cls;
  if(text!==undefined)e.textContent=text;
  return e;
}
function inr(n){
  const v=Number(n);
  return isNaN(v)?"Not available":"₹"+v.toLocaleString("en-IN");
}
function prettyDate(s){
  const d=new Date(s);
  if(!s||isNaN(d))return s||"—";
  return d.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"});
}
function row(label,value,valueCls){
  const r=el("div","rc-row");
  r.appendChild(el("span","",label));
  r.appendChild(el("b",valueCls||"",value));
  return r;
}
function statusPill(text){
  const t=String(text||"").toLowerCase();
  let cls="info";
  if(/approved|success|resolved|open/.test(t))cls="ok";
  else if(/review|pending|progress/.test(t))cls="warn";
  else if(/reject|error|fail|not applied|blocked/.test(t))cls="err";
  return el("span","pill "+cls,text);
}

function feeCard(it){
  const c=el("div","rc");
  c.appendChild(el("div","rc-title","💳 Fee Summary"));
  c.appendChild(row("Total fee",inr(it.total_fee)));
  c.appendChild(row("Paid amount",inr(it.paid_amount)));
  const pending=Number(it.pending_amount)||0;
  c.appendChild(row("Pending amount",pending>0?inr(pending):"Fully paid ✅",pending>0?"pending":"clear"));
  c.appendChild(row("Due date",prettyDate(it.due_date)));
  const pct=it.total_fee>0?Math.round(it.paid_amount/it.total_fee*100):0;
  const bar=el("div","bar"),fill=el("div");
  fill.style.width="0%";bar.appendChild(fill);c.appendChild(bar);
  setTimeout(()=>{fill.style.width=pct+"%";},60);
  c.appendChild(el("div","note",pct+"% of the academic fee paid"));
  return c;
}

function scholarshipCard(it){
  const c=el("div","rc");
  c.appendChild(el("div","rc-title","🎓 Scholarship Status"));
  c.appendChild(row("Scheme",it.scholarship||"—"));
  const r=el("div","rc-row");
  r.appendChild(el("span","","Application status"));
  r.appendChild(statusPill(it.application_status||"Unknown"));
  c.appendChild(r);
  c.appendChild(el("div","note","For official updates, contact the student support office."));
  return c;
}

function ticketCard(it){
  const c=el("div","rc");
  c.appendChild(el("div","rc-title","🎫 Support Request Created"));
  c.appendChild(row("Reference",it.ticket_id));
  const r=el("div","rc-row");
  r.appendChild(el("span","","Status"));
  r.appendChild(statusPill(it.ticket_status||"Open"));
  c.appendChild(r);
  c.appendChild(el("div","note","Keep this reference number for follow-up."));
  return c;
}

function policyCard(it){
  const c=el("div","rc");
  c.appendChild(el("div","rc-title","📘 Handbook Information"));
  const ev=Array.isArray(it.evidence)?it.evidence:[];
  if(!ev.length){
    c.appendChild(el("div","",it.message||"The handbook does not contain enough information to answer this."));
    c.appendChild(el("div","note","Please contact the relevant college office for confirmation."));
    return c;
  }
  ev.forEach(e=>{
    const box=el("div","ev");
    box.appendChild(el("span","tag","Source: "+(e.chunk_id||"Handbook")));
    box.appendChild(document.createTextNode((e.text||"").replace(/\n+/g,"\n")));
    c.appendChild(box);
  });
  c.appendChild(el("div","note","Answer is based only on the retrieved handbook sections."));
  return c;
}

function genericCard(it){
  const c=el("div","rc");
  const ok=it.status==="success";
  c.appendChild(el("div","rc-title",(ok?"✅ ":"⚠️ ")+(ok?"Done":"Notice")));
  c.appendChild(el("div","",it.message||JSON.stringify(it)));
  return c;
}

function renderItem(it){
  if(!it||typeof it!=="object")return genericCard({message:String(it)});
  if(it.total_fee!==undefined)return feeCard(it);
  if(it.scholarship!==undefined)return scholarshipCard(it);
  if(it.ticket_id!==undefined)return ticketCard(it);
  if(it.evidence!==undefined)return policyCard(it);
  return genericCard(it);
}

/* Returns {node, rich}. Falls back to plain text for normal model replies. */
function renderBot(text){
  const m=String(text).match(/^Here is the information I found:\s*([\s\S]*)$/);
  if(m){
    try{
      const items=JSON.parse(m[1]);
      if(Array.isArray(items)&&items.length){
        const box=document.createElement("div");
        items.forEach(it=>box.appendChild(renderItem(it)));
        return {node:box,rich:true};
      }
    }catch(e){}
  }
  const span=document.createElement("span");
  span.textContent=text;
  return {node:span,rich:false};
}

function addMessage(text,who){
  const empty=document.getElementById("empty");
  if(empty)empty.remove();
  const div=document.createElement("div");
  div.className="msg "+who;
  let body;
  if(who==="bot"){
    const r=renderBot(text);
    body=r.node;
    if(r.rich)div.classList.add("rich");
  }else{
    body=document.createElement("span");
    body.textContent=text;
  }
  const t=document.createElement("time");
  t.textContent=now();
  div.appendChild(body);div.appendChild(t);
  chat.appendChild(div);
  chat.scrollTop=chat.scrollHeight;
  return div;
}

function addTyping(){
  const div=document.createElement("div");
  div.className="msg bot";
  div.innerHTML='<span class="dots"><span></span><span></span><span></span></span>';
  chat.appendChild(div);
  chat.scrollTop=chat.scrollHeight;
  return div;
}

function setStatus(text,cls){
  const s=document.getElementById("status");
  s.textContent=text;s.className="small "+(cls||"");
}

async function login(){
  const id=document.getElementById("student").value.trim().toUpperCase();
  if(!id){setStatus("Please enter a student ID.","err");return;}
  try{
    const r=await fetch("/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({student_id:id})});
    const d=await r.json();
    setStatus(d.message,d.ok?"ok":"err");
    if(d.ok){
      studentId=id;
      const who=document.getElementById("who");
      who.textContent="👤 "+id;who.classList.remove("hidden");
      document.getElementById("clearBtn").classList.remove("hidden");
      document.getElementById("composer").classList.remove("hidden");
      document.getElementById("suggest").classList.remove("hidden");
      chat.innerHTML="";
      addMessage(d.message+"\nI can help with fees, scholarships, handbook policies and support tickets.","bot");
      document.getElementById("question").focus();
    }
  }catch(e){setStatus("Unable to reach the local server.","err");}
}

function ask(text){
  if(!studentId){setStatus("Please sign in first.","err");return;}
  document.getElementById("question").value=text;
  send();
}

async function send(){
  if(busy||!studentId)return;
  const input=document.getElementById("question");
  const question=input.value.trim();
  if(!question)return;
  input.value="";
  addMessage(question,"user");
  const typing=addTyping();
  busy=true;document.getElementById("sendBtn").disabled=true;
  try{
    const r=await fetch("/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({student_id:studentId,message:question})});
    const d=await r.json();
    typing.remove();
    addMessage(d.reply||d.message||"No response.","bot");
  }catch(e){
    typing.remove();
    addMessage("Unable to contact the local agent. Please check that the server is running.","bot");
  }
  busy=false;document.getElementById("sendBtn").disabled=false;
  input.focus();
}

function clearChat(){
  chat.innerHTML="";
  addMessage("Chat cleared. How can I help you?","bot");
}
</script>
</body></html>"""


class CampusMateHandler(BaseHTTPRequestHandler):
    agents = {}

    def log_message(self, *args):
        return

    def send_json(self, status, payload):
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        size = int(self.headers.get("Content-Length", "0"))
        if size > 10000:
            return {}
        return json.loads(self.rfile.read(size) or b"{}")

    def do_GET(self):
        if self.path == "/":
            raw = HTML_PAGE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        else:
            self.send_json(404, {"message": "Page not found."})

    def do_POST(self):
        data = self.read_json()
        if self.path == "/login":
            sid = str(data.get("student_id", "")).upper().strip()
            student = get_student(sid)
            if not student:
                return self.send_json(401, {"ok": False, "message": "Student ID not found."})
            self.send_json(200, {
                "ok": True,
                "message": "Welcome, " + student["student_name"] + ". You can ask your question."
            })
            return

        if self.path == "/chat":
            sid = str(data.get("student_id", "")).upper().strip()
            message = str(data.get("message", "")).strip()[:1000]
            if not get_student(sid):
                return self.send_json(401, {"reply": "Please enter a valid student ID first."})
            if not message:
                return self.send_json(400, {"reply": "Please type a question."})
            if sid not in self.agents:
                self.agents[sid] = StudentAgent(sid, SERVER_LLM)
            reply = self.agents[sid].respond(message)
            return self.send_json(200, {"reply": reply})
        self.send_json(404, {"message": "Endpoint not found."})


# ---------------------------------------------------------------------
# 8. COMMAND-LINE CHAT AND APPLICATION STARTUP
# ---------------------------------------------------------------------

def run_cli(llm):
    print("\nCampusMate Student Support Agent")
    print("Demo IDs: STU1001, STU1002, STU1003")
    sid = input("Enter student ID: ").strip().upper()
    try:
        agent = StudentAgent(sid, llm)
    except ValueError as error:
        print(error)
        return

    print(f"Welcome, {agent.student_name}. Type 'exit' to stop.\n")
    while True:
        question = input("You: ").strip()
        if question.lower() in ("exit", "quit"):
            break
        if question:
            print("CampusMate:", agent.respond(question), "\n")
            print("Trace:", json.dumps(agent.last_trace, indent=2), "\n")


def start_server(llm, port):
    global SERVER_LLM
    SERVER_LLM = llm
    server = ThreadingHTTPServer(("127.0.0.1", port), CampusMateHandler)
    print(f"\nCampusMate is running at http://127.0.0.1:{port}")
    print("Press Ctrl+C to stop the server.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nCampusMate server stopped.")
    finally:
        server.server_close()


# ---------------------------------------------------------------------
# 9. STUDENT DATA UTILITIES AND VALIDATION
# ---------------------------------------------------------------------

import csv
import hashlib
import statistics
from collections import Counter, defaultdict


def normalize_student_id(value):
    """Normalize a student identifier before looking up a record."""
    return str(value or "").strip().upper()


def validate_student_id(value):
    """Return (is_valid, normalized_value, explanation)."""
    normalized = normalize_student_id(value)
    if not normalized:
        return False, normalized, "Student ID is required."
    if len(normalized) > 20:
        return False, normalized, "Student ID is too long."
    if not re.fullmatch(r"[A-Z0-9_-]+", normalized):
        return False, normalized, "Use letters, numbers, hyphens or underscores only."
    return True, normalized, "Student ID format is valid."


def validate_question(question):
    """Validate a user prompt before it enters the agent loop."""
    value = str(question or "").strip()
    if not value:
        return False, "Please enter a question."
    if len(value) > 2000:
        return False, "The question is too long. Please keep it under 2,000 characters."
    if len(value) < 2:
        return False, "Please provide a little more detail."
    return True, value


def safe_text(value, max_length=500):
    """Convert arbitrary values to bounded plain text."""
    text_value = str(value or "").replace("\x00", " ").strip()
    return text_value[:max_length]


def format_currency(amount):
    """Format an integer amount in Indian rupee notation."""
    try:
        amount = int(amount)
    except (TypeError, ValueError):
        return "Not available"
    sign = "-" if amount < 0 else ""
    digits = str(abs(amount))
    if len(digits) > 3:
        last_three = digits[-3:]
        leading = digits[:-3]
        groups = []
        while leading:
            groups.insert(0, leading[-2:])
            leading = leading[:-2]
        digits = ",".join(groups + [last_three])
    return "₹" + sign + digits


def get_student_summary(student_id):
    """Return a student-facing summary without exposing database internals."""
    valid, normalized, message = validate_student_id(student_id)
    if not valid:
        return {"status": "error", "message": message}
    student = get_student(normalized)
    if not student:
        return {"status": "not_found", "message": "No student record was found."}
    pending = max(0, student["fee_total"] - student["fee_paid"])
    return {
        "status": "success",
        "student_id": normalized,
        "name": student["student_name"],
        "programme": student["programme"],
        "fee_total": format_currency(student["fee_total"]),
        "fee_paid": format_currency(student["fee_paid"]),
        "fee_pending": format_currency(pending),
        "fee_due_date": student["fee_due_date"],
        "scholarship": student["scholarship"],
        "scholarship_status": student["scholarship_status"]
    }


def calculate_fee_percentage(student_id):
    """Calculate the percentage of the academic fee already paid."""
    student = get_student(normalize_student_id(student_id))
    if not student or student["fee_total"] <= 0:
        return None
    return round(student["fee_paid"] / student["fee_total"] * 100, 2)


def list_demo_students():
    """List the sample records included for demonstration purposes."""
    with connect_db() as db:
        rows = db.execute(
            "SELECT student_id, student_name, programme FROM students ORDER BY student_id"
        ).fetchall()
    return [dict(row) for row in rows]


# ---------------------------------------------------------------------
# 10. SUPPORT TICKET MANAGEMENT AND REPORTING
# ---------------------------------------------------------------------

def get_ticket(ticket_id):
    """Fetch one ticket by its reference number."""
    ticket_id = safe_text(ticket_id, 30).upper()
    with connect_db() as db:
        row = db.execute(
            "SELECT * FROM support_tickets WHERE ticket_id = ?", (ticket_id,)
        ).fetchone()
    return dict(row) if row else None


def list_student_tickets(student_id, limit=20):
    """Return recent support tickets belonging to one student."""
    sid = normalize_student_id(student_id)
    with connect_db() as db:
        rows = db.execute(
            """SELECT ticket_id, category, description, status, created_at
               FROM support_tickets WHERE student_id = ?
               ORDER BY created_at DESC LIMIT ?""",
            (sid, max(1, min(int(limit), 100)))
        ).fetchall()
    return [dict(row) for row in rows]


def update_ticket_status(ticket_id, new_status):
    """Update a demo ticket status using a constrained status vocabulary."""
    allowed = {"Open", "In Progress", "Resolved", "Closed"}
    status = safe_text(new_status, 30).title()
    if status not in allowed:
        return {"status": "error", "message": "Unsupported ticket status."}
    with connect_db() as db:
        cursor = db.execute(
            "UPDATE support_tickets SET status = ? WHERE ticket_id = ?",
            (status, safe_text(ticket_id, 30).upper())
        )
    if cursor.rowcount == 0:
        return {"status": "not_found", "message": "Ticket was not found."}
    return {"status": "success", "ticket_id": ticket_id, "new_status": status}


def ticket_statistics():
    """Summarize ticket volume by status and category."""
    with connect_db() as db:
        status_rows = db.execute(
            "SELECT status, COUNT(*) AS total FROM support_tickets GROUP BY status"
        ).fetchall()
        category_rows = db.execute(
            "SELECT category, COUNT(*) AS total FROM support_tickets GROUP BY category"
        ).fetchall()
        total = db.execute("SELECT COUNT(*) FROM support_tickets").fetchone()[0]
    return {
        "total": total,
        "by_status": {row["status"]: row["total"] for row in status_rows},
        "by_category": {row["category"]: row["total"] for row in category_rows}
    }


def print_ticket_report(student_id=None):
    """Print ticket information for a student or the full demo dataset."""
    if student_id:
        tickets = list_student_tickets(student_id)
        heading = "SUPPORT TICKETS FOR " + normalize_student_id(student_id)
    else:
        with connect_db() as db:
            tickets = [dict(row) for row in db.execute(
                "SELECT * FROM support_tickets ORDER BY created_at DESC"
            ).fetchall()]
        heading = "ALL SUPPORT TICKETS"
    print("\n" + heading)
    print("-" * 88)
    if not tickets:
        print("No support tickets found.")
        return
    for ticket in tickets:
        print("Reference :", ticket["ticket_id"])
        print("Category  :", ticket["category"])
        print("Status    :", ticket["status"])
        print("Created   :", ticket["created_at"])
        print("Details   :", ticket["description"])
        print("-" * 88)


# ---------------------------------------------------------------------
# 11. MEMORY MANAGEMENT AND PRIVACY HELPERS
# ---------------------------------------------------------------------

def clear_student_memory(student_id):
    """Delete stored conversation memory for a single demo student."""
    sid = normalize_student_id(student_id)
    with connect_db() as db:
        cursor = db.execute(
            "DELETE FROM conversation_memory WHERE student_id = ?", (sid,)
        )
    return cursor.rowcount


def memory_statistics():
    """Return memory counts without returning the memory text itself."""
    with connect_db() as db:
        total = db.execute("SELECT COUNT(*) FROM conversation_memory").fetchone()[0]
        students = db.execute(
            "SELECT COUNT(DISTINCT student_id) FROM conversation_memory"
        ).fetchone()[0]
    return {"memory_items": total, "students_with_memory": students}


def contains_sensitive_pattern(text_value):
    """Conservative pattern check for common secrets and payment data."""
    patterns = [
        r"(?i)\bpassword\b", r"(?i)\bpasscode\b", r"(?i)\botp\b",
        r"(?i)\bcvv\b", r"\b\d{16}\b", r"\b\d{3,4}\b"
    ]
    return any(re.search(pattern, str(text_value or "")) for pattern in patterns)


def redact_sensitive_text(text_value):
    """Remove obvious secret-like values before logging or summarizing."""
    value = str(text_value or "")
    value = re.sub(
        r"(?i)(password|passcode|otp|cvv)\s*[:=]?\s*\S+",
        r"\1=[REDACTED]", value
    )
    value = re.sub(r"\b\d{16}\b", "[CARD NUMBER REDACTED]", value)
    return value[:1000]


def privacy_report():
    """Describe the local demo's storage footprint."""
    stats = memory_statistics()
    return {
        "database_file": DB_FILE.name,
        "trace_file": TRACE_FILE.name,
        "memory_items": stats["memory_items"],
        "students_with_memory": stats["students_with_memory"],
        "policy_file": HANDBOOK_FILE.name,
        "note": "Use fictional records only; this prototype is not a production student system."
    }


# ---------------------------------------------------------------------
# 12. TRACE ANALYTICS AND EVALUATION EXPORT
# ---------------------------------------------------------------------
def read_trace_records():
    """Read valid JSONL trace records and skip malformed lines safely."""
    if not TRACE_FILE.exists():
        return []
    records = []
    for line_number, line in enumerate(
        TRACE_FILE.read_text(encoding="utf-8").splitlines(), start=1
    ):
        try:
            item = json.loads(line)
            if isinstance(item, dict):
                records.append(item)
        except json.JSONDecodeError:
            print("Warning: skipped malformed trace line", line_number)
    return records


def trace_summary(records=None):
    """Calculate operational metrics from agent trace records."""
    records = read_trace_records() if records is None else records
    if not records:
        return {
            "total_interactions": 0,
            "average_latency_seconds": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "tool_frequency": {},
            "errors": 0
        }
    latencies = [float(row.get("latency_seconds", 0)) for row in records]
    tool_counts = Counter()
    for row in records:
        for call in row.get("tool_calls", []):
            tool_counts[call.get("tool", "unknown")] += 1
    return {
        "total_interactions": len(records),
        "average_latency_seconds": round(statistics.mean(latencies), 3),
        "median_latency_seconds": round(statistics.median(latencies), 3),
        "total_input_tokens": sum(int(row.get("input_tokens", 0)) for row in records),
        "total_output_tokens": sum(int(row.get("output_tokens", 0)) for row in records),
        "tool_frequency": dict(tool_counts),
        "errors": sum(1 for row in records if row.get("error"))
    }


def print_trace_report():
    """Display trace analytics in a readable terminal report."""
    report = trace_summary()
    print("\nCAMPUSMATE TRACE ANALYTICS")
    print("-" * 60)
    print("Total interactions       :", report["total_interactions"])
    print("Average latency (seconds):", report["average_latency_seconds"])
    print("Median latency (seconds) :", report.get("median_latency_seconds", 0))
    print("Input tokens             :", report["total_input_tokens"])
    print("Output tokens            :", report["total_output_tokens"])
    print("Errors                   :", report["errors"])
    print("Tool frequency           :")
    for tool_name, count in report["tool_frequency"].items():
        print("  -", tool_name, ":", count)


def export_traces_csv(destination=None):
    """Export trace-level metrics to CSV for assignment evaluation."""
    destination = Path(destination or ROOT / "evaluation_traces.csv")
    records = read_trace_records()
    columns = [
        "trace_id", "time", "student_id", "question", "answer",
        "latency_seconds", "input_tokens", "output_tokens", "tools",
        "retrieved_chunks", "error"
    ]
    with destination.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        for row in records:
            writer.writerow({
                "trace_id": row.get("trace_id", ""),
                "time": row.get("time", ""),
                "student_id": row.get("student_id", ""),
                "question": redact_sensitive_text(row.get("question", "")),
                "answer": redact_sensitive_text(row.get("answer", "")),
                "latency_seconds": row.get("latency_seconds", 0),
                "input_tokens": row.get("input_tokens", 0),
                "output_tokens": row.get("output_tokens", 0),
                "tools": "; ".join(
                    call.get("tool", "") for call in row.get("tool_calls", [])
                ),
                "retrieved_chunks": "; ".join(row.get("retrieved_chunks", [])),
                "error": row.get("error", "")
            })
    return destination


def export_students_csv(destination=None):
    """Export fictional student records for a local assignment demo."""
    destination = Path(destination or ROOT / "demo_students.csv")
    with connect_db() as db:
        rows = db.execute(
            "SELECT student_id, student_name, programme, fee_total, fee_paid, "
            "fee_due_date, scholarship, scholarship_status FROM students ORDER BY student_id"
        ).fetchall()
    with destination.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            "student_id", "student_name", "programme", "fee_total", "fee_paid",
            "fee_due_date", "scholarship", "scholarship_status"
        ])
        writer.writerows([tuple(row) for row in rows])
    return destination


# ---------------------------------------------------------------------
# 13. KNOWLEDGE BASE INSPECTION AND RETRIEVAL QUALITY
# ---------------------------------------------------------------------
def list_policy_sections():
    """Return distinct policy headings from the sample handbook."""
    if not HANDBOOK_FILE.exists():
        return []
    sections = []
    for line in HANDBOOK_FILE.read_text(encoding="utf-8").splitlines():
        candidate = line.strip()
        if candidate and candidate.isupper() and len(candidate) < 80:
            if candidate not in sections:
                sections.append(candidate)
    return sections


def inspect_policy_chunks():
    """Print chunk IDs and short previews for retrieval debugging."""
    chunks = split_policy_into_chunks()
    print("\nPOLICY RETRIEVAL INDEX")
    print("-" * 72)
    for chunk in chunks:
        preview = re.sub(r"\s+", " ", chunk.get("text", ""))[:180]
        print(chunk.get("chunk_id", "unknown"), "|", preview)
    if not chunks:
        print("No policy chunks were indexed.")


def retrieval_test_cases():
    """Small deterministic retrieval test set for the sample handbook."""
    return [
        ("attendance requirement", "attendance"),
        ("exam eligibility", "attendance"),
        ("scholarship application", "scholarship"),
        ("failed fee payment", "fees"),
        ("support office contact", "student support")
    ]


def evaluate_policy_retrieval():
    """Check whether expected policy topics are represented in retrieved chunks."""
    results = []
    for query, expected_word in retrieval_test_cases():
        matches = retrieve_policy(query, limit=3)
        combined = " ".join(item.get("text", "") for item in matches).lower()
        passed = expected_word.lower() in combined
        results.append({
            "query": query,
            "expected_topic": expected_word,
            "passed": passed,
            "retrieved": [item.get("chunk_id") for item in matches]
        })
    print("\nPOLICY RETRIEVAL CHECK")
    for row in results:
        print(
            ("PASS" if row["passed"] else "CHECK"),
            "|", row["query"], "| expected:", row["expected_topic"],
            "| chunks:", ", ".join(row["retrieved"])
        )
    return results


def explain_retrieval(question):
    """Return ranked policy evidence with a simple lexical relevance score."""
    terms = set(re.findall(r"[a-zA-Z]{3,}", question.lower()))
    scored = []
    for chunk in split_policy_into_chunks():
        words = set(re.findall(r"[a-zA-Z]{3,}", chunk.get("text", "").lower()))
        overlap = terms.intersection(words)
        score = len(overlap) / max(1, len(terms))
        if score:
            scored.append({
                "chunk_id": chunk.get("chunk_id"),
                "score": round(score, 3),
                "matched_terms": sorted(overlap),
                "text": chunk.get("text", "")
            })
    return sorted(scored, key=lambda row: row["score"], reverse=True)


# ---------------------------------------------------------------------
# 14. APPLICATION DIAGNOSTICS AND SELF-TESTS
# ---------------------------------------------------------------------
def check_application_files():
    """Check whether expected runtime files are present and readable."""
    checks = []
    for path in (DB_FILE, HANDBOOK_FILE):
        checks.append({
            "file": path.name,
            "exists": path.exists(),
            "readable": path.exists() and os.access(path, os.R_OK),
            "size_bytes": path.stat().st_size if path.exists() else 0
        })
    return checks


def check_database_tables():
    """Verify that all expected SQLite tables exist."""
    expected = {"students", "conversation_memory", "support_tickets"}
    with connect_db() as db:
        rows = db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    found = {row["name"] for row in rows}
    return {"expected": sorted(expected), "found": sorted(found), "missing": sorted(expected - found)}


def run_self_tests():
    """Run fast local checks that do not require an API key."""
    tests = []

    def record(name, condition, detail=""):
        tests.append({"test": name, "passed": bool(condition), "detail": detail})

    record("student ID normalization", normalize_student_id(" stu1001 ") == "STU1001")
    record("student ID validation", validate_student_id("STU1001")[0])
    record("reject invalid student ID", not validate_student_id("<script>")[0])
    record("question validation", validate_question("How do I check fees?")[0])
    record("reject blank question", not validate_question(" ")[0])
    record("demo student exists", get_student("STU1001") is not None)
    record("unknown student rejected", get_student("STU9999") is None)
    record("currency formatting", format_currency(150000) == "₹1,50,000")
    record("fee percentage", calculate_fee_percentage("STU1001") == 60.0)
    record("handbook exists", HANDBOOK_FILE.exists())
    record("policy chunks available", len(split_policy_into_chunks()) > 0)
    record("policy sections available", len(list_policy_sections()) > 0)
    record("database tables available", not check_database_tables()["missing"])
    record("safe text length", len(safe_text("x" * 1000, 20)) == 20)
    record("sensitive pattern detection", contains_sensitive_pattern("my OTP is 123456"))
    record("redaction", "[REDACTED]" in redact_sensitive_text("OTP: 123456"))

    print("\nCAMPUSMATE SELF-TESTS")
    print("-" * 72)
    for item in tests:
        print(("PASS" if item["passed"] else "FAIL"), "-", item["test"])
    passed = sum(1 for item in tests if item["passed"])
    print("-" * 72)
    print("Result:", passed, "/", len(tests), "passed")
    return tests


def print_system_diagnostics():
    """Print a compact diagnostic report before a demonstration."""
    print("\nCAMPUSMATE SYSTEM DIAGNOSTICS")
    print("-" * 72)
    print("Python version:", __import__("sys").version.split()[0])
    print("Project directory:", str(ROOT))
    print("Groq API key configured:", bool(os.getenv("GROQ_API_KEY")))
    print("Model:", MODEL)
    for item in check_application_files():
        print(
            item["file"], "exists:", item["exists"],
            "readable:", item["readable"], "bytes:", item["size_bytes"]
        )
    tables = check_database_tables()
    print("Database tables:", ", ".join(tables["found"]))
    print("Missing tables:", ", ".join(tables["missing"]) or "None")
    print("Demo students:", len(list_demo_students()))
    print("Policy chunks:", len(split_policy_into_chunks()))
    print("Trace records:", len(read_trace_records()))


# ---------------------------------------------------------------------
# 15. DEMONSTRATION PROMPTS AND HELP CONTENT
# ---------------------------------------------------------------------
DEMO_PROMPTS = [
    "What is my current fee status?",
    "Can you check my scholarship application?",
    "What attendance is required to sit for examinations?",
    "What does the handbook say about failed fee payments?",
    "Create a support ticket because my student portal is not working.",
    "Remember that I prefer short answers.",
    "Does the handbook guarantee a fee deadline extension?"
]


def print_help_guide():
    """Print a short guide for students and evaluators."""
    print("\nCAMPUSMATE - QUICK GUIDE")
    print("-" * 72)
    print("Student record questions:")
    print("  Ask about fee balances or scholarship application status.")
    print("Policy questions:")
    print("  Ask about attendance, fees, scholarships or support procedures.")
    print("Support requests:")
    print("  Explain the issue and ask CampusMate to create a support ticket.")
    print("Memory:")
    print("  Ask the agent to remember a non-sensitive response preference.")
    print("Sample student IDs:")
    for student in list_demo_students():
        print("  -", student["student_id"], "|", student["student_name"])
    print("\nSuggested demo questions:")
    for index, prompt in enumerate(DEMO_PROMPTS, start=1):
        print(f"  {index}. {prompt}")


def print_student_directory():
    """Print only the synthetic sample student directory."""
    print("\nDEMO STUDENT DIRECTORY")
    print("-" * 72)
    for student in list_demo_students():
        print(
            student["student_id"], "|", student["student_name"],
            "|", student["programme"]
        )


def show_student_profile(student_id):
    """Display the profile fields intended for the student demo."""
    summary = get_student_summary(student_id)
    print("\nSTUDENT PROFILE")
    print("-" * 72)
    if summary["status"] != "success":
        print(summary["message"])
        return
    for key, value in summary.items():
        if key != "status":
            print(key.replace("_", " ").title() + ":", value)


# ---------------------------------------------------------------------
# 16. LIGHTWEIGHT DATA QUALITY AND APPLICATION HELPERS
# ---------------------------------------------------------------------
def validate_student_fee_records():
    """Check for impossible fee values in the synthetic database."""
    problems = []
    with connect_db() as db:
        rows = db.execute("SELECT * FROM students").fetchall()
    for row in rows:
        if row["fee_total"] < 0:
            problems.append(row["student_id"] + ": negative total fee")
        if row["fee_paid"] < 0:
            problems.append(row["student_id"] + ": negative paid amount")
        if row["fee_paid"] > row["fee_total"]:
            problems.append(row["student_id"] + ": paid amount exceeds total fee")
    return problems


def validate_ticket_records():
    """Check ticket records for missing identifiers and invalid states."""
    valid_statuses = {"Open", "In Progress", "Resolved", "Closed"}
    problems = []
    with connect_db() as db:
        rows = db.execute("SELECT * FROM support_tickets").fetchall()
    for row in rows:
        if not row["ticket_id"]:
            problems.append("Ticket without reference ID")
        if row["status"] not in valid_statuses:
            problems.append(row["ticket_id"] + ": invalid status")
        if not get_student(row["student_id"]):
            problems.append(row["ticket_id"] + ": student record missing")
    return problems


def run_data_quality_report():
    """Run database consistency checks and print the findings."""
    fee_issues = validate_student_fee_records()
    ticket_issues = validate_ticket_records()
    print("\nDATA QUALITY REPORT")
    print("-" * 72)
    print("Fee record issues:", len(fee_issues))
    for issue in fee_issues:
        print("  -", issue)
    print("Ticket record issues:", len(ticket_issues))
    for issue in ticket_issues:
        print("  -", issue)
    if not fee_issues and not ticket_issues:
        print("No data quality issues found in the demo database.")
    return {"fee_issues": fee_issues, "ticket_issues": ticket_issues}


def create_demo_snapshot(destination=None):
    """Create a compact JSON snapshot of non-sensitive demo metrics."""
    destination = Path(destination or ROOT / "campusmate_snapshot.json")
    snapshot = {
        "generated_at": timestamp(),
        "student_count": len(list_demo_students()),
        "ticket_statistics": ticket_statistics(),
        "memory_statistics": memory_statistics(),
        "trace_summary": trace_summary(),
        "data_quality": run_data_quality_report()
    }
    destination.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
    return destination


def get_application_version():
    """Return the demonstration version label."""
    return "CampusMate 1.1 - Assignment 1 Prototype"


def print_application_banner():
    """Print application identity and key operating notes."""
    print("=" * 72)
    print("CAMPUSMATE | INTELLIGENT STUDENT SUPPORT AGENT")
    print(get_application_version())
    print("Agent loop | Tool calling | SQLite memory | Handbook retrieval | Tracing")
    print("=" * 72)


def validate_runtime_configuration(port=None):
    """Validate basic runtime settings before launching the web server."""
    issues = []
    if port is not None and not (1 <= int(port) <= 65535):
        issues.append("Port must be between 1 and 65535.")
    if MAX_TOOL_ROUNDS < 1:
        issues.append("MAX_TOOL_ROUNDS must be at least one.")
    if not API_URL.startswith("https://"):
        issues.append("API endpoint must use HTTPS.")
    return issues


def print_policy_sections():
    """Print the headings detected in the local handbook."""
    print("\nHANDBOOK SECTIONS")
    print("-" * 72)
    sections = list_policy_sections()
    if not sections:
        print("No section headings found.")
        return
    for number, section in enumerate(sections, start=1):
        print(f"{number}. {section.title()}")


def print_privacy_report():
    """Display a human-readable privacy and storage report."""
    report = privacy_report()
    print("\nPRIVACY AND LOCAL STORAGE")
    print("-" * 72)
    for key, value in report.items():
        print(key.replace("_", " ").title() + ":", value)


def print_fee_overview():
    """Summarize the synthetic fee dataset without exposing extra fields."""
    with connect_db() as db:
        row = db.execute(
            "SELECT COUNT(*) AS students, SUM(fee_total) AS total, "
            "SUM(fee_paid) AS paid FROM students"
        ).fetchone()
    total = int(row["total"] or 0)
    paid = int(row["paid"] or 0)
    print("\nDEMO FEE OVERVIEW")
    print("-" * 56)
    print("Students:", row["students"])
    print("Total fee:", format_currency(total))
    print("Paid fee:", format_currency(paid))
    print("Pending fee:", format_currency(total - paid))
    print("Collection rate:", round(paid / total * 100, 2) if total else 0, "%")


def tool_catalogue():
    """Return a compact description of tools exposed to the agent."""
    descriptions = {
        "check_fee_status": "Read the signed-in student's fee summary.",
        "check_scholarship_status": "Read the signed-in student's scholarship status.",
        "create_support_ticket": "Create a support request for the signed-in student.",
        "search_student_policy": "Retrieve relevant handbook evidence.",
        "save_student_preference": "Store a non-sensitive preference in SQLite memory."
    }
    return [{"name": name, "description": description}
            for name, description in descriptions.items()]


def print_tool_catalogue():
    """Print available agent tools for the project demonstration."""
    print("\nAGENT TOOL CATALOGUE")
    print("-" * 72)
    for item in tool_catalogue():
        print("-", item["name"])
        print("  ", item["description"])


def make_trace_fingerprint(trace):
    """Generate a stable digest for comparing a serialized trace."""
    canonical = json.dumps(trace, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def summarize_tool_calls(records=None):
    """Calculate average tool-call latency by tool name."""
    records = read_trace_records() if records is None else records
    durations = defaultdict(list)
    for record in records:
        for call in record.get("tool_calls", []):
            durations[call.get("tool", "unknown")].append(
                float(call.get("latency_seconds", 0))
            )
    return {
        name: {
            "calls": len(values),
            "average_latency_seconds": round(statistics.mean(values), 3)
        }
        for name, values in durations.items()
    }


def print_tool_performance():
    """Print the tool usage and latency summary."""
    summary = summarize_tool_calls()
    print("\nTOOL PERFORMANCE")
    print("-" * 72)
    if not summary:
        print("No tool-call traces are available yet.")
        return
    for name, values in summary.items():
        print(
            name, "| calls:", values["calls"],
            "| average latency:", values["average_latency_seconds"], "seconds"
        )


def list_recent_trace_questions(limit=10):
    """Return recent questions without exposing stored answers."""
    records = read_trace_records()
    return [
        {"time": row.get("time"), "student_id": row.get("student_id"),
         "question": redact_sensitive_text(row.get("question", ""))}
        for row in records[-max(1, min(int(limit), 100)):]
    ]


def print_recent_questions(limit=10):
    """Print recent prompt history from the trace file."""
    print("\nRECENT INTERACTIONS")
    print("-" * 72)
    rows = list_recent_trace_questions(limit)
    if not rows:
        print("No interactions recorded yet.")
        return
    for row in rows:
        print(row.get("time", ""), "|", row.get("student_id", ""))
        print("  ", row.get("question", ""))


def print_retrieval_explanation(question):
    """Show which policy chunks overlap with a user question."""
    print("\nRETRIEVAL EXPLANATION")
    print("-" * 72)
    rows = explain_retrieval(question)
    if not rows:
        print("No matching handbook text was found.")
        return
    for row in rows:
        print(row["chunk_id"], "| score:", row["score"])
        print("Matched terms:", ", ".join(row["matched_terms"]))
        print(row["text"][:400])


def export_all_reports():
    """Generate the common CSV and JSON artefacts for assignment review."""
    outputs = [export_traces_csv(), export_students_csv(), create_demo_snapshot()]
    print("\nREPORT FILES CREATED")
    for output in outputs:
        print("-", output.name)
    return outputs


def initialize_demo_environment():
    """Initialize local data files and the SQLite schema."""
    create_handbook_if_missing()
    setup_database()
    return {
        "database": str(DB_FILE),
        "handbook": str(HANDBOOK_FILE),
        "policy_chunks": len(split_policy_into_chunks()),
        "students": len(list_demo_students())
    }


def print_initialization_summary():
    """Print a concise summary after local initialization."""
    result = initialize_demo_environment()
    print("\nINITIALIZATION COMPLETE")
    print("Database:", result["database"])
    print("Handbook:", result["handbook"])
    print("Students loaded:", result["students"])
    print("Policy chunks:", result["policy_chunks"])


def print_data_dictionary():
    """Describe the local tables used by the application."""
    dictionary = {
        "students": ["student_id", "student_name", "programme", "fee_total",
                     "fee_paid", "fee_due_date", "scholarship", "scholarship_status"],
        "conversation_memory": ["memory_id", "student_id", "memory_text", "created_at"],
        "support_tickets": ["ticket_id", "student_id", "category", "description",
                            "status", "created_at"]
    }
    print("\nDATABASE DATA DICTIONARY")
    print("-" * 72)
    for table, fields in dictionary.items():
        print(table)
        for field in fields:
            print("  -", field)


def count_policy_words():
    """Count words in the local policy source document."""
    if not HANDBOOK_FILE.exists():
        return 0
    return len(re.findall(r"\b\w+\b", HANDBOOK_FILE.read_text(encoding="utf-8")))


def print_policy_statistics():
    """Display basic size statistics for the retrieval corpus."""
    chunks = split_policy_into_chunks()
    print("\nPOLICY CORPUS STATISTICS")
    print("-" * 72)
    print("Source file:", HANDBOOK_FILE.name)
    print("Word count:", count_policy_words())
    print("Chunk count:", len(chunks))
    print("Section count:", len(list_policy_sections()))
    print("Average chunk characters:", round(
        statistics.mean([len(item.get("text", "")) for item in chunks]), 1
    ) if chunks else 0)


def validate_policy_file():
    """Check that the handbook contains readable text and useful content."""
    if not HANDBOOK_FILE.exists():
        return ["Handbook file does not exist."]
    content = HANDBOOK_FILE.read_text(encoding="utf-8").strip()
    issues = []
    if len(content) < 100:
        issues.append("Handbook content is unusually short.")
    if not list_policy_sections():
        issues.append("No uppercase section headings were detected.")
    if not split_policy_into_chunks():
        issues.append("No retrieval chunks were generated.")
    return issues


def run_full_diagnostics():
    """Combine self-tests, data checks and policy validation."""
    print_system_diagnostics()
    test_results = run_self_tests()
    quality = run_data_quality_report()
    policy_issues = validate_policy_file()
    print("Policy validation issues:", len(policy_issues))
    for issue in policy_issues:
        print("-", issue)
    return {
        "self_tests_passed": sum(1 for item in test_results if item["passed"]),
        "self_tests_total": len(test_results),
        "data_quality": quality,
        "policy_issues": policy_issues
    }


# ---------------------------------------------------------------------
# 17. EXTENDED COMMAND-LINE OPTIONS
# ---------------------------------------------------------------------
def run_extended_command(args):
    """Execute one of the optional reporting or diagnostic commands."""
    if args.self_test:
        run_self_tests()
        return True
    if args.diagnostics:
        run_full_diagnostics()
        return True
    if args.report:
        print_trace_report()
        print_tool_performance()
        return True
    if args.export:
        export_all_reports()
        return True
    if args.tickets:
        print_ticket_report(args.tickets if args.tickets != "all" else None)
        return True
    if args.profile:
        show_student_profile(args.profile)
        return True
    if args.clear_memory:
        valid, sid, message = validate_student_id(args.clear_memory)
        if not valid:
            print(message)
        elif not get_student(sid):
            print("Student record was not found.")
        else:
            print("Deleted memory entries:", clear_student_memory(sid))
        return True
    if args.policy_index:
        inspect_policy_chunks()
        print_policy_statistics()
        return True
    if args.help_guide:
        print_help_guide()
        print_tool_catalogue()
        return True
    if args.directory:
        print_student_directory()
        print_fee_overview()
        return True
    return False


def main():
    global POLICY_CHUNKS
    parser = argparse.ArgumentParser(description="CampusMate Student Support Agent")
    parser.add_argument("--offline", action="store_true", help="Run without the Groq API.")
    parser.add_argument("--cli", action="store_true", help="Use terminal chat.")
    parser.add_argument("--eval", action="store_true", help="Run the sample evaluation.")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--self-test", action="store_true", help="Run local self-tests.")
    parser.add_argument("--diagnostics", action="store_true", help="Run full diagnostics.")
    parser.add_argument("--report", action="store_true", help="Show trace and tool analytics.")
    parser.add_argument("--export", action="store_true", help="Export CSV and JSON reports.")
    parser.add_argument("--tickets", metavar="STUDENT_ID", help="List tickets for a student or use 'all'.")
    parser.add_argument("--profile", metavar="STUDENT_ID", help="Show a demo student profile.")
    parser.add_argument("--clear-memory", metavar="STUDENT_ID", help="Clear memory for a demo student.")
    parser.add_argument("--policy-index", action="store_true", help="Inspect handbook retrieval chunks.")
    parser.add_argument("--help-guide", action="store_true", help="Show demo guide and available tools.")
    parser.add_argument("--directory", action="store_true", help="Show demo directory and fee overview.")
    args = parser.parse_args()

    print_application_banner()
    create_handbook_if_missing()
    POLICY_CHUNKS = split_policy_into_chunks()
    setup_database()
    if run_extended_command(args):
        return
    config_issues = validate_runtime_configuration(args.port)
    if config_issues:
        for issue in config_issues:
            print("Configuration error:", issue)
        return
    llm, model_label = make_llm(args.offline)

    print("Model:", model_label)
    print("Policy chunks loaded:", len(POLICY_CHUNKS))

    if args.eval:
        run_evaluation(llm)
    elif args.cli:
        run_cli(llm)
    else:
        start_server(llm, args.port)


if __name__ == "__main__":
    main()
